"""
Tkinter front-end for TeamsInstructionGenerator.

Lets you fill in Goal / Reference / Customer, generates the Markdown via
Azure AI Foundry, renders it (so you can sanity-check formatting), and gives
you a one-click "Copy Markdown" button to paste straight into Teams/email.

Run:
    .venv/bin/python gui.py
"""

import os
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk

import markdown
from tkinterweb import HtmlFrame

from TeamsInstructionGenerator import generate_instructions

API_KEY = os.environ.get("AZURE_FOUNDRY_API_KEY")

HEADING_CSS = """
body { font-family: sans-serif; font-size: 14px; }
h1, h2, h3 {
    font-size: 15px;
    font-family: sans-serif;
    margin: 14px 0 6px 0;
}
h1 { font-weight: 700; }
h2 { font-weight: 700; color: #1a1a1a; }
h3 { font-weight: 600; color: #333333; }
"""


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Teams Instruction Generator")
        self.geometry("900x700")

        self.markdown_text = ""

        self._build_form()
        self._build_output()

    def _build_form(self):
        form = ttk.Frame(self, padding=10)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="Platform").grid(row=0, column=0, sticky="w", pady=4)
        self.platform_entry = ttk.Entry(form)
        self.platform_entry.grid(row=0, column=1, sticky="ew", pady=4, padx=(8, 0))
        self.platform_entry.insert(0, "Sentinel")

        ttk.Label(form, text="Goal").grid(row=1, column=0, sticky="nw", pady=4)
        self.goal_text = tk.Text(form, height=3, wrap="word")
        self.goal_text.grid(row=1, column=1, sticky="ew", pady=4, padx=(8, 0))
        self.goal_text.insert(
            "1.0", "Instructions on deploying the Tenable vulnerability connector in Sentinel"
        )

        ttk.Label(form, text="Reference link").grid(row=2, column=0, sticky="w", pady=4)
        self.ref_entry = ttk.Entry(form)
        self.ref_entry.grid(row=2, column=1, sticky="ew", pady=4, padx=(8, 0))

        ttk.Label(form, text="Customer").grid(row=3, column=0, sticky="w", pady=4)
        self.customer_entry = ttk.Entry(form)
        self.customer_entry.grid(row=3, column=1, sticky="ew", pady=4, padx=(8, 0))

        button_row = ttk.Frame(form)
        button_row.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 0))

        self.generate_button = ttk.Button(
            button_row, text="Generate", command=self.on_generate
        )
        self.generate_button.pack(side="left")

        self.copy_button = ttk.Button(
            button_row, text="Copy Markdown", command=self.on_copy, state="disabled"
        )
        self.copy_button.pack(side="left", padx=(8, 0))

        self.status_label = ttk.Label(button_row, text="")
        self.status_label.pack(side="left", padx=(12, 0))

    def _build_output(self):
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        rendered_tab = ttk.Frame(notebook)
        notebook.add(rendered_tab, text="Rendered")
        self.html_frame = HtmlFrame(rendered_tab, messages_enabled=False)
        self.html_frame.pack(fill="both", expand=True)
        self._render_html("<i>Generated instructions will appear here.</i>")

        raw_tab = ttk.Frame(notebook)
        notebook.add(raw_tab, text="Raw Markdown")
        self.raw_text = scrolledtext.ScrolledText(raw_tab, wrap="word")
        self.raw_text.pack(fill="both", expand=True)

    def _render_html(self, html):
        self.html_frame.load_html(html)
        self.html_frame.add_css(HEADING_CSS)

    def on_generate(self):
        platform = self.platform_entry.get().strip()
        goal = self.goal_text.get("1.0", "end").strip()
        ref = self.ref_entry.get().strip()
        customer = self.customer_entry.get().strip()

        if not platform or not goal or not ref or not customer:
            messagebox.showwarning(
                "Missing fields",
                "Please fill in Platform, Goal, Reference link, and Customer.",
            )
            return

        if not API_KEY:
            messagebox.showerror(
                "Missing API key",
                "AZURE_FOUNDRY_API_KEY is not set. Add it to your .env file and restart.",
            )
            return

        self.generate_button.config(state="disabled")
        self.copy_button.config(state="disabled")
        self.status_label.config(text="Generating...")

        thread = threading.Thread(
            target=self._generate_worker,
            args=(goal, ref, customer, platform),
            daemon=True,
        )
        thread.start()

    def _generate_worker(self, goal, ref, customer, platform):
        try:
            result = generate_instructions(goal, ref, customer, platform, API_KEY)
            error = None
        except Exception as exc:
            result = None
            error = str(exc)

        self.after(0, self._on_generate_done, result, error)

    def _on_generate_done(self, result, error):
        self.generate_button.config(state="normal")
        self.status_label.config(text="")

        if error:
            messagebox.showerror("Generation failed", error)
            return

        self.markdown_text = result
        self.raw_text.delete("1.0", "end")
        self.raw_text.insert("1.0", result)

        html = markdown.markdown(result, extensions=["extra", "sane_lists"])
        self._render_html(html)

        self.copy_button.config(state="normal")

    def on_copy(self):
        if not self.markdown_text:
            return
        self.clipboard_clear()
        self.clipboard_append(self.markdown_text)
        self.status_label.config(text="Copied to clipboard!")
        self.after(2000, lambda: self.status_label.config(text=""))


if __name__ == "__main__":
    App().mainloop()
