"""
Generates customer onboarding/deployment instructions in Markdown by calling
an Azure AI Foundry model deployment (via the OpenAI-compatible /openai/v1 API).

Usage:
    export AZURE_FOUNDRY_API_KEY="<your-api-key>"
    python TeamsInstructionGenerator.py \
        --platform "Sentinel" \
        --goal "Instructions on deploying the Tenable vulnerability connector in Sentinel" \
        --ref "https://learn.microsoft.com/en-us/azure/sentinel/data-connectors/tenable" \
        --customer "Acme Corp"

The API key is read from the AZURE_FOUNDRY_API_KEY environment variable so it
never has to be hardcoded or committed to source control.
"""

import argparse
import os
import sys

from dotenv import load_dotenv
from openai import BadRequestError, OpenAI

load_dotenv()

ENDPOINT = "https://Foundry-POC-TP.services.ai.azure.com/openai/v1"
DEPLOYMENT_NAME = "gpt-4.1-mini"

SYSTEM_PROMPT = """You are a senior security engineer at Nomios writing \
customer-facing onboarding/deployment instructions for security technologies \
(e.g. Microsoft Sentinel, Tenable, Defender, etc.). Your readers are technical \
(customer IT/security staff) and will follow these instructions to actually \
perform the deployment, so accuracy and completeness matter more than brevity.

You have web search available. Use it whenever it would make the instructions \
more accurate or complete - to confirm exact menu paths, current permission/role \
names, prerequisites, connector-specific setup steps, known limitations, and \
recent changes to the product being deployed. Prefer official vendor \
documentation (Microsoft Learn, the vendor's own docs, etc.) as sources. Do not \
fabricate steps, settings, or URLs - if you are not confident about a detail, \
phrase it generically rather than inventing specifics.

Given a platform, a goal, a reference documentation link, and a customer name, \
write instructions in Markdown that STRICTLY follow this structure and \
formatting:

# {Platform} - {Component} deployment [{customer}]

As discussed, please find the following to onboard {component} into {platform}.

## Context

<2-4 sentences explaining what is being deployed, why it matters, and any \
background needed to understand the steps below - specific to this platform \
and component, not generic boilerplate.>

## Steps

### Platform

* **{customer}** - <one bullet per discrete action/confirmation the customer \
must perform or provide, in the order they're needed - e.g. specific accounts, \
credentials, licenses, firewall rules, or approvals. Break multi-part actions \
into separate bullets rather than one dense paragraph.>
* **Nomios** - <one bullet per discrete action Nomios will perform on the \
customer's behalf, in execution order - e.g. specific configuration steps, \
connector setup, validation checks.>

## Considerations

<a bulleted list of prerequisites, licensing requirements, permissions needed, \
known limitations, or risks specific to this platform/component. Draw on \
real, current information (via web search if useful) rather than generic \
filler. Omit this section only if genuinely nothing applies.>

**Reference**

* [<short descriptive link text>](<the originally provided reference URL>)
* [<short descriptive link text>](<any additional URL you consulted, one per \
bullet>)

Rules:
- Use the Platform exactly as given (e.g. "Sentinel") in the title - do not \
rename, translate, or infer a different one.
- Infer the Component (e.g. "Tenable") from the goal.
- Use the exact customer name as given, inside square brackets in the title, and \
as the bold label on the customer's bullet under Platform (not the literal word \
"Customer").
- ALWAYS include the originally provided reference URL as the first bullet under \
**Reference**, exactly as given, even if you also consulted other sources.
- If you used web search, append every additional source you actually drew \
information from as its own bullet under **Reference**, using its real URL. \
Never invent a URL. If you did not need to search, only the original reference \
appears.
- Be specific and technically detailed rather than generic - name actual \
settings, roles, permissions, or menu paths where you know them.
- Keep ALL Platform steps under the single "### Platform" heading shown above - \
both the {customer} bullets and the Nomios bullets belong under that one \
heading. Never create a separate "### {customer}" or "### Nomios" heading.
- Keep bullet points actionable and written as instructions/steps, not prose \
paragraphs.
- Do not include any text outside the Markdown document (no preamble, no \
explanation of what you did).
"""

USER_PROMPT_TEMPLATE = """Platform: {platform}
Goal: {goal}
Reference: {ref}
Customer: {customer}

Write the onboarding instructions now, following the required structure exactly."""


def generate_instructions(
    goal: str, ref: str, customer: str, platform: str, api_key: str
) -> str:
    client = OpenAI(base_url=ENDPOINT, api_key=api_key)
    user_input = USER_PROMPT_TEMPLATE.format(
        platform=platform, goal=goal, ref=ref, customer=customer
    )

    try:
        response = client.responses.create(
            model=DEPLOYMENT_NAME,
            instructions=SYSTEM_PROMPT,
            input=user_input,
            tools=[{"type": "web_search"}],
        )
    except BadRequestError:
        # This Foundry deployment may not support the hosted web_search tool -
        # fall back to generating from the model's own knowledge.
        response = client.responses.create(
            model=DEPLOYMENT_NAME,
            instructions=SYSTEM_PROMPT,
            input=user_input,
        )

    return response.output_text


def main():
    if len(sys.argv) == 1:
        from gui import App

        App().mainloop()
        return

    parser = argparse.ArgumentParser(
        description="Generate customer deployment instructions via Azure AI Foundry."
    )
    parser.add_argument(
        "--platform", required=True, help='e.g. "Sentinel"'
    )
    parser.add_argument(
        "--goal",
        required=True,
        help='e.g. "Instructions on deploying the Tenable vulnerability connector in Sentinel"',
    )
    parser.add_argument("--ref", required=True, help="Documentation reference link")
    parser.add_argument("--customer", required=True, help="Customer name")
    parser.add_argument(
        "--api-key",
        default=os.environ.get("AZURE_FOUNDRY_API_KEY"),
        help="Azure AI Foundry API key (defaults to AZURE_FOUNDRY_API_KEY env var)",
    )
    args = parser.parse_args()

    if not args.api_key:
        sys.exit(
            "Error: no API key provided. Set AZURE_FOUNDRY_API_KEY or pass --api-key."
        )

    markdown = generate_instructions(
        args.goal, args.ref, args.customer, args.platform, args.api_key
    )
    print(markdown)


if __name__ == "__main__":
    main()
